local map, data = ...

local puzzle = require 'maps/components/obstacle_puzzle/obstacle_puzzle'

puzzle.init(map, data)
