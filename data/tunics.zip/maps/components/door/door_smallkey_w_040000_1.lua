local map, data = ...

local door_smallkey = require 'maps/components/door/door_smallkey'

return door_smallkey.init(map, data, 2)
