local map, data = ...

local door_bigkey = require 'maps/components/door/door_bigkey'

return door_bigkey.init(map, data, 1)
