local map, data = ...

local door_veryweakwall = require 'maps/components/door/door_veryweakwall'

return door_veryweakwall.init(map, data, 3)
