local map, data = ...

local bomb = require 'maps/components/obstacle_veryweakwall/obstacle_veryweakwall'

bomb.init(map,data)
