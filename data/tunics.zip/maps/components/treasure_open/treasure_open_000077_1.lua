local map, data = ...

local treasure = require 'maps/components/treasure_open/treasure_open'

treasure.init(map, data)
