local map, data = ...

local treasure = require 'maps/components/treasure_bigkey/treasure_bigkey'

treasure.init(map, data)
