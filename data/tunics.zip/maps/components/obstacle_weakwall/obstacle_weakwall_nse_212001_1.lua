local map, data = ...

local bomb = require 'maps/components/obstacle_weakwall/obstacle_weakwall' 

bomb.init(map,data)
