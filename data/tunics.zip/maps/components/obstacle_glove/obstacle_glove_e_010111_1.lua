local map, data = ...

local glove = require 'maps/components/obstacle_glove/obstacle_glove'

glove.init(map, data)