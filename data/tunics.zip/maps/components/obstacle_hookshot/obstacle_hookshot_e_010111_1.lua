local map, data = ...

local hookshot = require 'maps/components/obstacle_hookshot/obstacle_hookshot'

hookshot.init(map, data)
