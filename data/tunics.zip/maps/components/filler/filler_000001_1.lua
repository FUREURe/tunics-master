local map, data = ...

local filler = require 'maps/components/filler/filler'

filler.init(map, data)
