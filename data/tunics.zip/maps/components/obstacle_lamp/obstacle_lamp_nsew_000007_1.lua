local map, data = ...

local lamp = require 'maps/components/obstacle_lamp/obstacle_lamp'

lamp.init(map,data,2000)
