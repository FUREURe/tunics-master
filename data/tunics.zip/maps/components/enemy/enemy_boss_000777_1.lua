local map, data = ...

local enemy_boss = require 'maps/components/enemy/enemy_boss'

enemy_boss.init(map, data)
