local map, data = ...

local bow = require 'maps/components/obstacle_bow/obstacle_bow'

bow.init(map,data)
