local map, data = ...

local flippers = require 'maps/components/obstacle_flippers/obstacle_flippers'

flippers.init(map, data)